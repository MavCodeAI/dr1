-- Insert sample data for testing

-- Insert sample products (Main products: Shilajit, Dry Fruits, Honey, Shilajit Drops)
INSERT INTO public.products (name, category, description, price, stock, min_stock, image_url) VALUES
('Premium Shilajit 50g', 'main', 'Pure Himalayan Shilajit resin, rich in minerals and fulvic acid. Authentic and lab-tested for quality.', 2500.00, 25, 5, 'https://images.unsplash.com/photo-1505944270255-72b8c68c6a70?w=400'),
('Shilajit Gold Capsules', 'main', 'Premium Shilajit capsules with gold flakes for enhanced potency and easier consumption.', 3500.00, 15, 3, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400'),
('Mixed Dry Fruits 1kg', 'main', 'Premium quality mix of almonds, walnuts, cashews, raisins, and pistachios. Perfect for gifting.', 1800.00, 50, 10, 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400'),
('Organic Almonds 500g', 'main', 'Raw, organic almonds sourced directly from Kashmir. Rich in proteins and healthy fats.', 1200.00, 30, 8, 'https://images.unsplash.com/photo-1508740535312-29b2effa6ba3?w=400'),
('Kashmiri Walnuts 500g', 'main', 'Premium quality Kashmiri walnuts, known for their superior taste and nutritional value.', 1500.00, 20, 5, 'https://images.unsplash.com/photo-1553430414-d42d9e3d4eb8?w=400'),
('Pure Forest Honey 500ml', 'main', 'Raw, unprocessed honey collected from wild forests. Rich in enzymes and natural antioxidants.', 800.00, 40, 8, 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400'),
('Acacia Honey 250ml', 'main', 'Light, mild-flavored honey perfect for daily consumption. Great for tea and cooking.', 450.00, 35, 7, 'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=400'),
('Shilajit Liquid Drops 30ml', 'main', 'Concentrated Shilajit extract in liquid form for faster absorption and convenience.', 1800.00, 12, 3, 'https://images.unsplash.com/photo-1585435421671-0ca2746f1cc9?w=400'),

-- Reseller items
('Organic Green Tea 100g', 'reseller', 'Premium organic green tea leaves with natural antioxidants.', 350.00, 25, 5, 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400'),
('Himalayan Pink Salt 1kg', 'reseller', 'Pure Himalayan pink salt, rich in minerals and perfect for cooking.', 280.00, 45, 10, 'https://images.unsplash.com/photo-1582296726046-6f1c7aaaf0e6?w=400'),
('Organic Turmeric Powder 200g', 'reseller', 'High-quality turmeric powder with high curcumin content.', 320.00, 30, 8, 'https://images.unsplash.com/photo-1615485020161-de7cd1b085ff?w=400'),
('Black Seed Oil 100ml', 'reseller', 'Cold-pressed black seed oil with numerous health benefits.', 650.00, 18, 4, 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400');

-- Note: The first user will be created automatically when someone signs up
-- The following sample data assumes there will be users in the system

-- Insert sample orders (will be created after users exist)
-- This is just the structure - actual data will be added through the application

-- Sample marketing posts
-- INSERT INTO public.marketing_posts (platform, title, content, status, scheduled_at, created_by) VALUES
-- ('facebook', 'New Shilajit Products Available!', 'Discover the power of Himalayan Shilajit! 🏔️\n\nOur premium quality Shilajit is now available:\n✅ Pure & Lab-tested\n✅ Rich in minerals\n✅ Authentic Himalayan source\n\nOrder now and experience the difference!\n\n#Shilajit #HealthyLiving #NaturalSupplements', 'scheduled', NOW() + INTERVAL '1 hour', (SELECT id FROM public.users WHERE role = 'owner' LIMIT 1));

-- Create a view for dashboard analytics
CREATE OR REPLACE VIEW dashboard_analytics AS
SELECT 
    -- Sales Summary
    COALESCE(SUM(CASE WHEN DATE(o.created_at) = CURRENT_DATE THEN o.total_amount END), 0) as today_sales,
    COALESCE(SUM(CASE WHEN DATE(o.created_at) >= DATE_TRUNC('week', CURRENT_DATE) THEN o.total_amount END), 0) as week_sales,
    COALESCE(SUM(CASE WHEN DATE(o.created_at) >= DATE_TRUNC('month', CURRENT_DATE) THEN o.total_amount END), 0) as month_sales,
    COALESCE(SUM(o.total_amount), 0) as total_sales,
    
    -- Order Counts
    COUNT(CASE WHEN o.status = 'pending' THEN 1 END) as pending_orders,
    COUNT(CASE WHEN o.status = 'processing' THEN 1 END) as processing_orders,
    COUNT(CASE WHEN DATE(o.created_at) = CURRENT_DATE THEN 1 END) as today_orders,
    
    -- Payment Summary
    COALESCE(SUM(CASE WHEN p.status = 'unpaid' THEN p.amount END), 0) as pending_payments,
    COALESCE(SUM(CASE WHEN p.status = 'partial' THEN p.amount END), 0) as partial_payments
    
FROM public.orders o
LEFT JOIN public.payments p ON o.id = p.order_id;

-- Create a view for low stock alerts
CREATE OR REPLACE VIEW low_stock_products AS
SELECT 
    id,
    name,
    category,
    stock,
    min_stock,
    price,
    (min_stock - stock) as shortage
FROM public.products 
WHERE stock <= min_stock AND is_active = true
ORDER BY (min_stock - stock) DESC;

-- Create a function to get sales data for charts
CREATE OR REPLACE FUNCTION get_sales_chart_data(days_back INTEGER DEFAULT 30)
RETURNS TABLE(
    date DATE,
    sales DECIMAL,
    orders INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        DATE(o.created_at) as date,
        COALESCE(SUM(o.total_amount), 0) as sales,
        COUNT(o.id)::INTEGER as orders
    FROM generate_series(
        CURRENT_DATE - INTERVAL '1 day' * days_back,
        CURRENT_DATE,
        INTERVAL '1 day'
    )::DATE AS date_series(date)
    LEFT JOIN public.orders o ON DATE(o.created_at) = date_series.date
    GROUP BY DATE(o.created_at), date_series.date
    ORDER BY date_series.date;
END;
$$ LANGUAGE plpgsql;

-- Create a function to get product performance
CREATE OR REPLACE FUNCTION get_product_performance(days_back INTEGER DEFAULT 30)
RETURNS TABLE(
    product_id UUID,
    product_name TEXT,
    category product_category,
    total_sold INTEGER,
    total_revenue DECIMAL,
    avg_price DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.id,
        p.name,
        p.category,
        COALESCE(SUM(oi.quantity)::INTEGER, 0) as total_sold,
        COALESCE(SUM(oi.subtotal), 0) as total_revenue,
        COALESCE(AVG(oi.price), 0) as avg_price
    FROM public.products p
    LEFT JOIN public.order_items oi ON p.id = oi.product_id
    LEFT JOIN public.orders o ON oi.order_id = o.id
    WHERE o.created_at >= CURRENT_DATE - INTERVAL '1 day' * days_back OR o.created_at IS NULL
    GROUP BY p.id, p.name, p.category
    ORDER BY total_revenue DESC;
END;
$$ LANGUAGE plpgsql;