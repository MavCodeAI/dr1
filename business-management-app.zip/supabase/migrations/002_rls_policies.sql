-- Row Level Security Policies

-- Enable RLS on all tables
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.marketing_posts ENABLE ROW LEVEL SECURITY;

-- Users policies
CREATE POLICY "Users can view their own profile" ON public.users
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.users
    FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Owners can view all users" ON public.users
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.users 
            WHERE id = auth.uid() AND role = 'owner'
        )
    );

CREATE POLICY "Owners can manage all users" ON public.users
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.users 
            WHERE id = auth.uid() AND role = 'owner'
        )
    );

-- Products policies
CREATE POLICY "Everyone can view active products" ON public.products
    FOR SELECT USING (is_active = true OR auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can manage products" ON public.products
    FOR ALL USING (auth.role() = 'authenticated');

-- Orders policies
CREATE POLICY "Users can view all orders" ON public.orders
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Users can create orders" ON public.orders
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Users can update orders" ON public.orders
    FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Owners can delete orders" ON public.orders
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM public.users 
            WHERE id = auth.uid() AND role = 'owner'
        )
    );

-- Order items policies
CREATE POLICY "Users can view order items" ON public.order_items
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Users can manage order items" ON public.order_items
    FOR ALL USING (auth.role() = 'authenticated');

-- Payments policies
CREATE POLICY "Users can view payments" ON public.payments
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Users can manage payments" ON public.payments
    FOR ALL USING (auth.role() = 'authenticated');

-- Inventory logs policies
CREATE POLICY "Users can view inventory logs" ON public.inventory_logs
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Users can create inventory logs" ON public.inventory_logs
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- Marketing posts policies
CREATE POLICY "Users can view marketing posts" ON public.marketing_posts
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Users can manage marketing posts" ON public.marketing_posts
    FOR ALL USING (auth.role() = 'authenticated');

-- Grant usage on sequences
GRANT USAGE ON SEQUENCE order_number_seq TO authenticated;
GRANT USAGE ON SEQUENCE order_number_seq TO anon;