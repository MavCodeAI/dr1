module.exports = {
  content: require('./tailwind.config.js').content,
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}